/**
 /**
 * <b>WordList</b> Add some description for this class WordList. and also at
 * each method you create
 * 
 * @author <IMAN TEH>
 * @version 1.0
 */
import javax.swing.*;
import java.util.*;
public class WordList {
	
	//initializing variables
    private Node first;
    private Node next;
    private Node last;
    private Node current;
    
    public int count() {
       int count = 1;
       for(Node n = first; n.next != null; n = n.next)
           count++;     
       return count;
    }
    
    
    public boolean isEmpty(){
        return(first == null);
    }
    //to insert a new item into node 
    public void insert(String insertItem){
        Node newNode = new Node(insertItem);
        if(isEmpty()){
            first = newNode;
            last = newNode;
        }
        else
        {
            last.next = newNode;
            last = newNode;
        }
    }
    
    // to get the next node 
    public String getNext(){
            if(current == last){
                return null;
            }
            else
                current = current.next;
            return current.word;
    }
    
    //to get the first node 
    public String getFirst(){
        if(isEmpty()){
            return null;
        }
        else
            current = first;
        return current.word;
    }
    
    //to get the last node 
    public String getLast(){
        if(isEmpty()){
            return null;
        }
        else
            current = last;
        return current.word;    
    }
    
    //remove the first node
    public String removeFromFront(){
        String removeItem = null;
        if(first == null){
            return removeItem;
        }
        removeItem = first.word;
        first = first.next;
        return removeItem;
    }
    
    //remove the back node
    public String removeFromBack(){
        String removeItem = null;
        if(isEmpty()){
            return removeItem;
        }
        removeItem = last.word;
        if(first == last){
            first = null;
            last = null;
        }
        else
        {
            current = first;
            while(current.next != last){
                current = current.next;
            }
            last = current;
            last.next = null;
        }
        return removeItem;
    }
    
    //method to find a word 
    public String find(String searchword){
        current = first;
        while(current != null){
            if(current.word.equalsIgnoreCase(searchword)){
                return current.word;
            }
            else
                current = current.next;
        }
        return null;
    }
    
    //method to find unique word
    public ArrayList<String> findUnique(Hashtable <String,String> worddict){
        
        ArrayList<String> uniquewords = new ArrayList<String>();
        String word = removeFromBack();
        String temp = null;
        int index = 0;
        while(word != null){
            Hashtable <String,String> tempdict = worddict;
            int counter = 0;
            if(tempdict.get(word) == null){
                break;
            }
            else{
                while(!tempdict.isEmpty()){
                    String tempword = null;
                    String remove = null;
                    System.out.println("Word: "+ word);
                    remove = tempdict.remove(word);
                    System.out.println("Word: "+ remove);
                    if(remove.equals(word)){
                        tempword = word;
                        counter++;
                        if(counter > 1){
                            break;
                        }
                        else{
                            uniquewords.add(tempword);
                        }
                    }
                }
            }
            word = removeFromBack();
        }
        return uniquewords;
    }
    //method to sort the list 
    public String sortList(){
        current = first;
        Node index = null;
        String temp = null;
        if(first == null){
            return null;
        }
        else{
            while(current != null){
                index = current.next;
                
                while(index != null){
                    if(current.word.compareTo(index.word) > 0){
                        temp = current.word;
                        current.word = index.word;
                        index.word = temp;
                    }
                    index = index.next;
                }
                current = current.next;
            }
        }
        return temp;
    }
    /**
     * Counts the number of words in the list
     * 
     * @return the number of words in the list
     */
    public class Node{
        String word;
        Node next;
        //default Node constructor
        public Node(){
            word = null;
            next = null; 
        } 
        //Normal Node constructor
        public Node(String obj){
            word = obj;
            next = null;
        }
        //get word
        public String getWord(){
            return this.word;
        }
        public String setWord(String word){
            return this.word = word;
        }
        public void insertAfter(String word, Node n){
            Node x = new Node(word);
            x.next = n.next;
            n.next = x;
        }
        public double ttr(int uniquewords, int totalword) {
    		//calculate ttr
    		double ttr = (double) uniquewords/totalword;
    		//return value
    		return ttr;
        }
    }
}