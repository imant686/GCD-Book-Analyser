

//import java.util.InputMismatchException;
//import java.util.Scanner;
//import java.util.ArrayList;
//import java.util.NegativeArraySizeException;
import java.util.*;

/**
 * Add some description for this class
 * 
 * @author <IMAN TEH>   
 * @version 1.0
 */
public class GCDCoprimeDemo {
	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		//array list is created for co prime function
		ArrayList<Integer> arrayCoPrime = new ArrayList<Integer>();

		try {

			System.out.println("--------- GREATEST COMMON DIVISOR -------------");
			
			//ask user to key in two positive integers to calculate GCD  
			System.out.println("Key in first number: ");
			//pass in method for getUserLongInput after gone through exception handling 
			long n = getUserLongInput(scanner);

			System.out.println("Key in second number: ");
			long m = getUserLongInput(scanner);

			//pass user input to euclid method to calculate GCD
			int EuclidGCD = (int) EuclidGCD(n, m);

			//display GCD 
			System.out.printf("G.C.D of %d and %d is: %d.", n, m, EuclidGCD);

			
			
			System.out.println("\n\n---------- CO-PRIME ---------------");
			int a;
			
				//ask user to key in a positive integer to calculate co-prime
				System.out.println("Enter a number to calculate the co-prime: ");
				a = getUserIntInput(scanner);

				//formula to calculate co-prime
				int c = 0;
				for (int i = a; i > 0; i--) {
					c = printcoPrime(a, i);
					if (c != 0) {
						arrayCoPrime.add(c);
					}
				}

				//exception if the user keys in a negative number
//				System.out.println("\nInput cannot be a negative number. Try again");


			//display co-prime of number  
			System.out.println("Co-prime of number " + a + " is: ");
			for (int j = 0; j < arrayCoPrime.size(); j++) {
				System.out.print(arrayCoPrime.get(j) + " ");
			}
			
			System.out.println("\n\n------------ GCD FOR NUMBER SEQUENCE -----------");
			try {
				//ask user to input size of array
				System.out.println("Enter the number of elements you want to store for number sequence : ");
				int gcdSize = getUserIntInput(scanner);
				
				int[] array = new int[gcdSize];
				
				//ask user to input positive number to store in array
				for (int counter = 0; counter < gcdSize; counter++) {
					System.out.println("Enter number " + (counter + 1) + " of array");
					array[counter] = getUserIntInput(scanner);
				}
				scanner.close();

				int result = array[0];

				// Loop through the array and find GCD by combining the GCD of previous numbers
				
				for (int i = 1; i < array.length; i++) {
					result = findGCD(array[i], result);

				}
				
				//display GCD of all numbers
				System.out.print("GCD of all numbers in array is: " + result);

			// exception handling if user input an invalid(negative integer)
			} catch (NegativeArraySizeException e) {
				System.out.println("Invalid input detected for array. Exit program!");
			}
			
			// main exception if user keys in any invalid input 
		} catch (InputMismatchException e) {
			System.out.println("Invalid input detected. Exit program!");
		}
	}

	// method to calculate the GCD of two positive integers
	public static long EuclidGCD(long n, long m) {
		if (n == 0 || m == 0) {
			return 0;
		}
		
		int remainder = (int) (n % m);
		if (remainder != 0)
			return EuclidGCD(m, remainder);
		else
			return m;
	}

	// method to print coprime
	public static int printcoPrime(int a, int i) {
		int coPrime = 0;
		if (findGCD(a, i) == 1)
			return coPrime = i;
		return coPrime;
	}

	//method to find GCD for number sequence
	public static int findGCD(int c, int d) {
		if (d == 0)
			return c;

		return findGCD(d, c % d);

	}

	//exception method if user input negative integers 
	public static long getUserLongInput(Scanner scanner) {
		long n;
		while (true) {

			String string = scanner.nextLine();

			try {
				n = Long.parseLong(string);
				if (n >= 0) {
					break;
				}
				System.out.println("Input String cannot be a negative number. Try again.\n");

			} catch (NumberFormatException e) {
				System.out.println("Input String cannot be parsed to Long. Try again.\n");
			}
		}
		return n;
	}

	public static int getUserIntInput(Scanner scanner) {
		int p;
		while (true) {
			String string = scanner.nextLine();

			try {
				p = Integer.parseInt(string);
				if (p >= 0) {
					break;
				}
				System.out.println("Input cannot be a negative number. Try again.\n");

			} catch (NumberFormatException e) {
				System.out.println("Input cannot be parsed to Int. Try again.\n");
			}
		}
		return p;
	}
}