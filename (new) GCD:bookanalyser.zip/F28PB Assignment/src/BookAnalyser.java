/**
 * <b>BookAnalyser</b> Add some description for this class BookAnalyser.
 * 
 * @author <IMAN TEH> 
 * @version 1.0
 */
import java.lang.*;
import java.io.*;
import java.util.StringTokenizer;
import java.util.Scanner;
import java.util.Arrays;
import java.util.Hashtable;
public class BookAnalyser {
    public static void main(String[] args) {
        try{
            //String s = "";
            Scanner scan = new Scanner(System.in);
            WordList word = new WordList(); //oldman.txt
	    WordList word2 = new WordList(); //acrosstheriver.txt
            //menu screen
            for(;;){
                //read from text file
                FileReader reader = new FileReader("hemingway_oldman.txt");
                FileReader reader2 = new FileReader("hemingway_acrosstheriver.txt");
		BufferedReader in = new BufferedReader(reader);
		BufferedReader in2 = new BufferedReader(reader2);
		//read oldman.txt
                String line;
                int i = 0;
                int count = 0;
                String[] stopwords = new String[]{"a", "an", "and", "are", "as", "at", "be", "by", "for", "from", "has", "he", "in", "is", "it", "its", "of", "on", "that", "the", "to", "was", "were", "will", "with"};
                while((line = in.readLine()) != null){
                    if(line.length() == 0){
                        continue;
                    }
                    if(line == null){
                        break;
                    }
                    //read line by line using \n
                    StringTokenizer token = new StringTokenizer(line,"\n");
                    String[] tosplit = token.nextToken().split(" ");
                
                    for(String a: tosplit){
                        int skip = 0;
                        if(a.equals("")){
                            //skip all the spaces
                            continue;
                        }else{ 
                            for(String each: stopwords){
                                if(each.equals(a.toLowerCase().replaceAll("[^A-Za-z0-9]", "").trim()))
                                    skip = 1;
                            }
                            if(skip == 0){
                                //insert into wordlist
                                word.insert(a.toLowerCase().replaceAll("[^A-Za-z0-9]", "").trim()); 
                            }
                            count++;
                        }

                    }
                    i++;
                }
		//read acrosstheriver.txt
                String line2;
                int j = 0;
                int count2 = 0;
                while((line2 = in.readLine()) != null){
                    if(line2.length() == 0){
                        continue;
                    }
                    if(line2 == null){
                        break;
                    }
                    //read line by line using \n
                    StringTokenizer token2 = new StringTokenizer(line2,"\n");
                    String[] tosplit2 = token2.nextToken().split(" ");
                
                    for(String a: tosplit2){
                        int skip = 0;
                        if(a.equals("")){
                            //skip all the spaces
                            continue;
                        }else{ 
                            for(String each: stopwords){
                                if(each.equals(a.toLowerCase().replaceAll("[^A-Za-z0-9]", "").trim()))
                                    skip = 1;
                            }
                            if(skip == 0){
                                //insert into wordlist
                                word2.insert(a.toLowerCase().replaceAll("[^A-Za-z0-9]", "").trim()); 
                            }
                            count++;
                        }

                    }
                    j++;
                }
                clearScreen();
        // ask user to input which text file (book) to read 
		System.out.println("1 - Hemingway Oldman");
		System.out.println("2 - Hemingway Across The River");
		
		//display choices
		System.out.print("Choice: ");
		int book = scan.nextInt();
		if(book == 1){
			System.out.println("one - Count total word of the novel");
                	System.out.println("two - Search the existence of a word");
                	System.out.println("three - Find unique words");
                	System.out.println("exit - Exit the program");
                	System.out.print("Choice: ");
                	String choice = scan.next();
                	switch(choice){
                		//find total number of words from text 
                    	case "one" : clearScreen();
                                 	totalword(word);
                                 	break;
                        //to search for a word
                    	case "two" : clearScreen();
                                 	searchword(word);
                                 	break;
                        //find unique word from text 
                    	case "three" :  clearScreen();
                                    	Hashtable <String,String> worddict = readFile();
                                    	System.out.println(word.findUnique(worddict).toString());
                                    	break;
                    	case "exit" : System.exit(0);
                	}
		}
		//same functions run if user inputs the other r text file 
		else if(book == 2){
			System.out.println("one - Count total word of the novel");
                	System.out.println("two - Search the existence of a word");
                	System.out.println("three - Find unique words");
                	System.out.println("exit - Exit the program");
                	System.out.print("Choice: ");
                	String choice = scan.next();
                	switch(choice){
                    	case "one" : clearScreen();
                                 	totalword(word2);
                                 	break;
                    	case "two" : clearScreen();
                                 	searchword(word2);
                                 	break;
                    	case "three" :  clearScreen();
                                    	Hashtable <String,String> worddict = readFile();
                                    	System.out.println(word2.findUnique(worddict).toString());
                                    	break;
                    	case "exit" : System.exit(0);
                	}
        // display exception of user entered invalid input 
		}else{System.out.println("Your choice is not in the available options!");     
            }        
        }
        }
        
        //exception handling if user keys in invalid input 
        catch(FileNotFoundException fnf){System.out.println("File Not Found!");}
        catch(IOException ex){System.out.println("Error in reading the file!");}
    }
    public static Hashtable<String,String> readFile(){
        Hashtable<String,String> worddict = new Hashtable<String, String>();
        try{
            FileReader reader = new FileReader("hemingway_oldman.txt");
            BufferedReader in = new BufferedReader(reader);
            String line;
            int i = 0;
            int count = 0;
            
            //words put into array to be eliminated 
            String[] stopwords = new String[]{"a", "an", "and", "are", "as", "at", "be", "by", "for", "from", "has", "he", "in", "is", "it", "its", "of", "on", "that", "the", "to", "was", "were", "will", "with"};
            while((line = in.readLine()) != null){
                if(line.length() == 0){
                    continue;
                }
                if(line == null){
                    break;
                }
                //read line by line using \n
                StringTokenizer token = new StringTokenizer(line,"\n");
                String[] tosplit = token.nextToken().split(" ");
                
                for(String a: tosplit){
                    int skip = 0;
                    if(a.equals("")){
                        //skip all the spaces
                        continue;
                    }else{ 
                        for(String each: stopwords){
                            if(each.equals(a.toLowerCase().replaceAll("[^A-Za-z0-9]", "").trim()))
                                skip = 1;
                        }
                        if(skip == 0){
                            String tempword = a.toLowerCase().replaceAll("[^A-Za-z0-9]", "").trim();
                            //insert into worddict
                            worddict.put(tempword, tempword); 
                        }
                        count++;
                    }

                }
                i++;
            }
        }
        //exception handling
        catch(FileNotFoundException fnf){System.out.println("File Not Found!");}
        catch(IOException ex){System.out.println("Error in reading the file!");}
        return worddict;
    }
    public static void clearScreen() {  //add some line space
        System.out.println();
        System.out.println();
    }  
    
    //method to find the total number of words
    public static void totalword(WordList w){
        System.out.println("Total word count from the book: " + w.count());
    }
    
    //method to search a word in text 
    public static void searchword(WordList w){
        Scanner scan = new Scanner(System.in);
        System.out.print("Search for a word(if it returns the word, it exists in this novel): ");
        String input = scan.next();
        System.out.println(w.find(input));
    }
    
    //method to find unique word in text 
    public static void findunique(WordList w){
        System.out.println(w.sortList());
    }
    
//    public static void findtopKWords() {
//    	
//    }
    
    
}



