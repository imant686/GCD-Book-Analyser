import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test; 

public class GCDTest {

	@Before 
	public void setUp() {
		System.out.println("Test is still generating....");
	}
	
	
	@Test
	public void test() {
		GCDCoprimeDemo test = new GCDCoprimeDemo();
		
		assertEquals(1,GCDCoprimeDemo.EuclidGCD(1, 2) );
		assertEquals(3, GCDCoprimeDemo.EuclidGCD(12, 33));
		
		assertEquals(1, GCDCoprimeDemo.printcoPrime(1, 1));
		assertEquals(1, GCDCoprimeDemo.printcoPrime(2, 1));
		
		
		assertEquals(1, GCDCoprimeDemo.findGCD(1, 1));
		assertEquals(1, GCDCoprimeDemo.findGCD(1, 2));
		
		}
		@After 
		public void after() {
		System.out.println("Test has completed");
		}
	
}