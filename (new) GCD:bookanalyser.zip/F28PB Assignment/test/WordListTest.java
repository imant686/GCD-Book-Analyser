import static org.junit.Assert.*;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader; 
import java.io.IOException;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;

public class WordListTest {
	@Before
	public void setup() {
		System.out.println("Test is starting...");
	}
	
	@Test
	public void testA() throws FileNotFoundException {
		
		BookAnalyser test = new BookAnalyser ();
		
		assertEquals(17270, BookAnalyser.totalword(w.count()));
	}
	
	@After
	public void after () {
		System.out.println("Test has completed ");
	}

}
	
